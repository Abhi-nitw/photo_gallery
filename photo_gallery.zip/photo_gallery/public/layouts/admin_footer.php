</div>
	<div id="footer">Copyright &copy;&nbsp;<?php echo date("Y", time()); ?>, Abhishek Singh</div>
</body>
</html>