<html>
<head>
	<title>Photo Gallery: Admin</title>
	<link rel="stylesheet" type="text/css" media="all" href="../stylesheet/main.css">
</head>
<body>
	<div id="header">
      <h1>Photo Gallery : Admin</h1>
    </div>
    <div id="main">