<html>
<head>
	<title>Photo Gallery</title>
	<link rel="stylesheet" type="text/css" media="all" href="stylesheet/main.css">
</head>
<body>
	<div id="header">
      <h1>Photo Gallery</h1>
    </div>
    <div id="main">