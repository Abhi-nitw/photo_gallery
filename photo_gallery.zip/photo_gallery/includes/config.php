<?php 
	//DATABASE CONSTANTS 
	// WE have to define only Once , if already defined do nothing;
	defined("DB_SERVER") ? null : define("DB_SERVER", "localhost");
	defined("DB_USER") ? null : define("DB_USER", "gallery");
	defined("DB_PASS") ? null : define("DB_PASS", "Abhi@8801");
	defined("DB_NAME") ? null : define("DB_NAME", "photo_gallery");
?>